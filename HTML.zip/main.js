// Preloader
window.addEventListener("load", () => {
    document.querySelector(".preloader").style.opacity = "0";
    setTimeout(() => {
        document.querySelector(".preloader").style.display = "none";
    }, 500);
});

// Fade-in effect
document.addEventListener("DOMContentLoaded", () => {
    const fadeElements = document.querySelectorAll(".fade-in");
    fadeElements.forEach((el, index) => {
        setTimeout(() => {
            el.style.opacity = "1";
            el.style.transform = "translateY(0)";
        }, index * 300);
    });

    // Slide-in effect
    const slideElements = document.querySelectorAll(".slide-in");
    slideElements.forEach((el, index) => {
        setTimeout(() => {
            el.style.opacity = "1";
            el.style.transform = "translateX(0)";
        }, index * 300);
    });
});